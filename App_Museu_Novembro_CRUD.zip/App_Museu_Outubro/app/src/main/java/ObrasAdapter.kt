package com.example.app_museu

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.firestore.FirebaseFirestore

class ObrasAdapter(private var obrasList: MutableList<Obra>) :
    RecyclerView.Adapter<ObrasAdapter.ObraViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ObraViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.card_obra_admin, parent, false)
        return ObraViewHolder(view)
    }

    override fun onBindViewHolder(holder: ObraViewHolder, position: Int) {
        val obra = obrasList[position]
        holder.titulo.text = obra.titulo
        holder.autor.text = obra.autor
        holder.tema.text = obra.tema
        holder.data.text = obra.data
        holder.descricao.text = obra.descricao

        holder.buttonEdit.setOnClickListener {
            val intent = Intent(holder.itemView.context, TelaEditarObra::class.java)
            intent.putExtra("titulo_obra", obra.titulo)
            holder.itemView.context.startActivity(intent)
        }


        holder.buttonDelete.setOnClickListener {
            val db = FirebaseFirestore.getInstance()

            db.collection("obras")
                .whereEqualTo("titulo", obra.titulo)
                .get()
                .addOnSuccessListener { querySnapshot ->
                    if (!querySnapshot.isEmpty) {
                        val documentId = querySnapshot.documents[0].id
                        db.collection("obras").document(documentId)
                            .delete()
                            .addOnSuccessListener {
                                Toast.makeText(holder.itemView.context, "Obra deletada com sucesso!", Toast.LENGTH_SHORT).show()
                                removeItemAt(position)
                            }
                            .addOnFailureListener { e ->
                                Toast.makeText(holder.itemView.context, "Erro ao deletar obra: ${e.message}", Toast.LENGTH_SHORT).show()
                            }
                    } else {
                        Toast.makeText(holder.itemView.context, "Obra não encontrada!", Toast.LENGTH_SHORT).show()
                    }
                }
                .addOnFailureListener { e ->
                    Toast.makeText(holder.itemView.context, "Erro ao buscar obra: ${e.message}", Toast.LENGTH_SHORT).show()
                }
        }
    }

    override fun getItemCount(): Int = obrasList.size

    fun updateList(newList: List<Obra>) {
        obrasList.clear()
        obrasList.addAll(newList)
        notifyDataSetChanged()
    }

    private fun removeItemAt(position: Int) {
        obrasList.removeAt(position)
        notifyItemRemoved(position)
        notifyItemRangeChanged(position, itemCount)
    }

    class ObraViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val titulo: TextView = itemView.findViewById(R.id.titulo)
        val autor: TextView = itemView.findViewById(R.id.autor)
        val tema: TextView = itemView.findViewById(R.id.tema)
        val data: TextView = itemView.findViewById(R.id.data)
        val descricao: TextView = itemView.findViewById(R.id.descricao)
        val buttonEdit: Button = itemView.findViewById(R.id.ButtonEditObra)
        val buttonDelete: Button = itemView.findViewById(R.id.ButtonRemoveObra)
    }
}
