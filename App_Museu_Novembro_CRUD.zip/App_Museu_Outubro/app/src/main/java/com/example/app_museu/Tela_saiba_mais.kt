package com.example.app_museu

import android.os.Bundle
import android.util.Log
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.app_museu.databinding.ActivityTelaSaibaMaisBinding

class Tela_saiba_mais : AppCompatActivity() {

    private lateinit var binding: ActivityTelaSaibaMaisBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityTelaSaibaMaisBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val sharedPref = getSharedPreferences("AppMuseuPrefs", 0)

        val titulo = sharedPref.getString("obra_titulo", "Título não disponível")
        val autor = sharedPref.getString("obra_autor", "Autor desconhecido")
        val data = sharedPref.getString("obra_data", "Data desconhecida")
        val tema = sharedPref.getString("obra_tema", "Tema não informado")
        val descricao = sharedPref.getString("obra_descricao", "Descrição não disponível")
        val cover = sharedPref.getInt("obra_cover", R.drawable.default_image) // Defina uma imagem padrão

        binding.cover.setImageResource(cover)
        binding.titulo.text = titulo
        binding.autor.text = autor
        binding.data.text = data
        binding.tema.text = tema
        binding.obraDescricao.text = descricao
    }

}