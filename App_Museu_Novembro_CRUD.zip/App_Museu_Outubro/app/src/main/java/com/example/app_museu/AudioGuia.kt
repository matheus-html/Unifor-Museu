package com.example.app_museu

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.app_museu.databinding.FragmentAudioGuiaBinding
import com.google.firebase.firestore.FirebaseFirestore

class AudioGuia : Fragment(), ObraClickListener {

    private lateinit var binding: FragmentAudioGuiaBinding
    private lateinit var db: FirebaseFirestore
    private val listaObras = mutableListOf<Obra>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentAudioGuiaBinding.inflate(inflater, container, false)
        db = FirebaseFirestore.getInstance()
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        loadObrasFromFirebase()
    }

    private fun loadObrasFromFirebase() {
        db.collection("obras")
            .get()
            .addOnSuccessListener { documents ->
                for (document in documents) {
                    val obra = document.toObject(Obra::class.java)
                    listaObras.add(obra)
                }

                binding.recyclerViewObrasAUDIOGUIA.layoutManager = LinearLayoutManager(requireContext(), LinearLayoutManager.VERTICAL, false)
                val adapter = ObraAdapter(listaObras, this)
                binding.recyclerViewObrasAUDIOGUIA.adapter = adapter
            }
            .addOnFailureListener { exception ->
                exception.printStackTrace()
            }
    }

    override fun onClick(obra: Obra) {
        val intent = Intent(requireContext(), Tela_AudioObra::class.java).apply {
            putExtra("obra_titulo", obra.titulo)
            putExtra("obra_autor", obra.autor)
            putExtra("obra_data", obra.data)
            putExtra("obra_tema", obra.tema)
            putExtra("obra_descricao", obra.descricao)
            putExtra("obra_cover", obra.cover)
        }
        startActivity(intent)
    }
}
