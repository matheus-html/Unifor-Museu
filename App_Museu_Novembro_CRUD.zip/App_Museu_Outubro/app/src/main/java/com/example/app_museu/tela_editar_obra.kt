package com.example.app_museu

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.firestore.FirebaseFirestore

class TelaEditarObra : AppCompatActivity() {

    private lateinit var editTextTitulo: EditText
    private lateinit var editTextAutor: EditText
    private lateinit var editTextData: EditText
    private lateinit var editTextTema: EditText
    private lateinit var editTextDescricao: EditText
    private lateinit var buttonSalvarEdit: Button
    private lateinit var buttonAddImage: Button
    private var obraImageUri: Uri? = null
    private val db = FirebaseFirestore.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tela_editar_obra)

        editTextTitulo = findViewById(R.id.editTextTitulo)
        editTextAutor = findViewById(R.id.editTextAutor)
        editTextData = findViewById(R.id.editTextData)
        editTextTema = findViewById(R.id.editTextTema)
        editTextDescricao = findViewById(R.id.editTextDescricao)
        buttonSalvarEdit = findViewById(R.id.buttonSalvarEdit)
        buttonAddImage = findViewById(R.id.buttonAddImage)

        val titulo = intent.getStringExtra("titulo_obra") ?: return
        carregarDadosObra(titulo)

        buttonAddImage.setOnClickListener {
            val intent = Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
            resultLauncher.launch(intent)
        }

        buttonSalvarEdit.setOnClickListener {
            val updatedObra = Obra(
                autor = editTextAutor.text.toString(),
                titulo = editTextTitulo.text.toString(),
                data = editTextData.text.toString(),
                tema = editTextTema.text.toString(),
                descricao = editTextDescricao.text.toString()
            )
            updateObraInFirestore(updatedObra, titulo)
        }
    }

    private val resultLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val data: Intent? = result.data
                obraImageUri = data?.data
            }
        }

    private fun carregarDadosObra(titulo: String) {
        db.collection("obras").whereEqualTo("titulo", titulo).get()
            .addOnSuccessListener { querySnapshot ->
                if (!querySnapshot.isEmpty) {
                    val document = querySnapshot.documents[0]
                    val obra = document.toObject(Obra::class.java)
                    obra?.let {
                        editTextTitulo.setText(it.titulo)
                        editTextAutor.setText(it.autor)
                        editTextData.setText(it.data)
                        editTextTema.setText(it.tema)
                        editTextDescricao.setText(it.descricao)
                    }
                } else {
                    Toast.makeText(this, "Obra não encontrada", Toast.LENGTH_SHORT).show()
                }
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Erro ao carregar dados: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }

    private fun updateObraInFirestore(obra: Obra, titulo: String) {
        db.collection("obras").whereEqualTo("titulo", titulo).get()
            .addOnSuccessListener { querySnapshot ->
                if (!querySnapshot.isEmpty) {
                    val documentId = querySnapshot.documents[0].id
                    db.collection("obras").document(documentId)
                        .set(obra)
                        .addOnSuccessListener {
                            Toast.makeText(this, "Obra atualizada com sucesso!", Toast.LENGTH_SHORT).show()
                            finish()
                        }
                        .addOnFailureListener { e ->
                            Toast.makeText(this, "Erro ao atualizar obra: ${e.message}", Toast.LENGTH_SHORT).show()
                        }
                }
            }
    }
}
