package com.example.app_museu

import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.TextToSpeech.OnInitListener
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.app_museu.databinding.ActivityTelaAudioObraBinding
import com.google.firebase.firestore.FirebaseFirestore
import java.util.*

class Tela_AudioObra : AppCompatActivity(), OnInitListener {
    private lateinit var binding: ActivityTelaAudioObraBinding
    private lateinit var tts: TextToSpeech
    private var isPlaying = false
    private var currentPosition = 0
    private lateinit var listaObras: List<Obra>
    private val db = FirebaseFirestore.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTelaAudioObraBinding.inflate(layoutInflater)
        setContentView(binding.root)

        tts = TextToSpeech(this, this)

        currentPosition = intent.getIntExtra("obra_position", 0)

        loadObrasFromFirebase()

        binding.play.setOnClickListener { togglePlay() }
        binding.back.setOnClickListener { obraAnterior() }
        binding.forward.setOnClickListener { proximaObra() }
    }

    private fun loadObrasFromFirebase() {
        db.collection("obras")
            .get()
            .addOnSuccessListener { result ->
                listaObras = result.documents.map { doc ->
                    Obra(
                        titulo = doc.getString("titulo") ?: "",
                        autor = doc.getString("autor") ?: "",
                        data = doc.getString("data") ?: "",
                        tema = doc.getString("tema") ?: "",
                        descricao = doc.getString("descricao") ?: ""
                    )
                }

                if (listaObras.isNotEmpty()) {
                    if (currentPosition >= listaObras.size) {
                        currentPosition = listaObras.size - 1
                    }
                    loadObraData(currentPosition)
                }
            }
            .addOnFailureListener { exception ->
                Toast.makeText(this, "Erro ao carregar dados do Firestore", Toast.LENGTH_SHORT).show()
            }
    }

    private fun loadObraData(position: Int) {
        if (position >= 0 && position < listaObras.size) {
            val obra = listaObras[position]
            binding.obraTitulo.text = obra.titulo
            binding.obraAutor.text = obra.autor
            binding.obraData.text = obra.data
            binding.obraTema.text = obra.tema
            binding.obraDescricao.text = obra.descricao
        }
    }

    private fun togglePlay() {
        if (isPlaying) {
            pauseSpeech()
        } else {
            playDescription()
        }
    }

    private fun playDescription() {
        val description = binding.obraDescricao.text.toString()
        tts.speak(description, TextToSpeech.QUEUE_FLUSH, null, null)
        isPlaying = true
        binding.play.setImageResource(android.R.drawable.ic_media_pause)
    }

    private fun pauseSpeech() {
        tts.stop()
        isPlaying = false
        binding.play.setImageResource(android.R.drawable.ic_media_play)
    }

    private fun obraAnterior() {
        if (currentPosition > 0) {
            if (isPlaying) {
                pauseSpeech()
            }
            currentPosition--
            loadObraData(currentPosition)
        }
    }

    private fun proximaObra() {
        if (currentPosition < listaObras.size - 1) {
            if (isPlaying) {
                pauseSpeech()
            }
            currentPosition++
            loadObraData(currentPosition)
        }
    }


    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts.language = Locale("pt", "BR")
        } else {
            Toast.makeText(this, "Erro ao inicializar o TTS", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroy() {
        if (::tts.isInitialized) {
            tts.stop()
            tts.shutdown()
        }
        super.onDestroy()
    }
}
