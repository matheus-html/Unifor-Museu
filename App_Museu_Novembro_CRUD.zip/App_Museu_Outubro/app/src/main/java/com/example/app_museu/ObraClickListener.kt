package com.example.app_museu

interface ObraClickListener {
    fun onClick(obra: Obra)
}
