package com.example.app_museu

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.app_museu.databinding.CardCellBinding

class ObraAdapter(
    private var obras: List<Obra>,
    private val clickListener: ObraClickListener
) : RecyclerView.Adapter<CardViewHolder>() {

    companion object {
        const val TIPO_PADRAO = 0
        const val TIPO_ADMIN = 1
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CardViewHolder {
        val from = LayoutInflater.from(parent.context)
        val binding = CardCellBinding.inflate(from, parent, false)

        return CardViewHolder(binding, clickListener)
    }



    override fun getItemViewType(position: Int): Int {
        return if (obras[position].isAdminAdded) {
            TIPO_ADMIN
        } else {
            TIPO_PADRAO
        }
    }

    override fun getItemCount(): Int = obras.size

    override fun onBindViewHolder(holder: CardViewHolder, position: Int) {
        holder.bindObra(obras[position])
    }
}
