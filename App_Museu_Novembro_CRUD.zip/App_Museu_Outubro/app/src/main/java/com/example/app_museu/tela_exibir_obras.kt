package com.example.app_museu

import android.app.Activity

class tela_exibir_obras : Activity()
