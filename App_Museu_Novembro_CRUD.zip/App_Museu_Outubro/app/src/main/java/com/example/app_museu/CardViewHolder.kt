package com.example.app_museu

import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.example.app_museu.databinding.CardCellBinding

class CardViewHolder(
    private val cardCellBinding: CardCellBinding,
    private val clickListener: ObraClickListener
) : RecyclerView.ViewHolder(cardCellBinding.root) {

    fun bindObra(obra: Obra) {
        // omitindo o código relacionado ao cover
        // por enquanto, o cover não será utilizado neste código

        cardCellBinding.titulo.text = obra.titulo
        cardCellBinding.autor.text = obra.autor
        cardCellBinding.data.text = obra.data
        cardCellBinding.tema.text = obra.tema

        updateFavoriteIcon(obra)

        cardCellBinding.cardView.setOnClickListener {
            clickListener.onClick(obra)
        }

        cardCellBinding.audioGuiaBotaoHome.setOnClickListener {
            val context = cardCellBinding.root.context
            val intent = Intent(context, Tela_AudioObra::class.java).apply {
                putExtra("obra_titulo", obra.titulo)
                putExtra("obra_autor", obra.autor)
                putExtra("obra_data", obra.data)
                putExtra("obra_tema", obra.tema)
                putExtra("obra_descricao", obra.descricao)
                putExtra("obra_position", adapterPosition)
            }
            context.startActivity(intent)
        }

        cardCellBinding.toggleButton2.setOnClickListener {
            toggleFavorite(obra)
        }
    }

    private fun toggleFavorite(obra: Obra) {
        val context = cardCellBinding.root.context
        val favoritos = ObrasRepository.getFavoritos()

        if (favoritos.contains(obra.titulo)) {
            ObrasRepository.removeFromFavoritos(obra.titulo)
            Toast.makeText(context, "${obra.titulo} removida dos favoritos", Toast.LENGTH_SHORT).show()
        } else {
            ObrasRepository.addToFavoritos(obra.titulo)
            Toast.makeText(context, "${obra.titulo} adicionada aos favoritos", Toast.LENGTH_SHORT).show()
        }

        updateFavoriteIcon(obra)
    }

    private fun updateFavoriteIcon(obra: Obra) {
        cardCellBinding.toggleButton2.isChecked = ObrasRepository.isFavorito(obra.titulo)
    }
}
