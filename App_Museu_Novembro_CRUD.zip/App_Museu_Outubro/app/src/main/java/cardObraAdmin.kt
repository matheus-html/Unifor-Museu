class cardObraAdmin {
}